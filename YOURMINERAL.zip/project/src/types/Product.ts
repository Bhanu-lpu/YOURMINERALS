// Product type definition
export interface Product {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating: {
    rate: number;
    count: number;
  };
}

// Categories type
export type Category = 
  | "electronics"
  | "jewelery"
  | "men's clothing"
  | "women's clothing";