import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, Italic as Crystal } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';

const Header: React.FC = () => {
  const { cart } = useCart();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement search functionality
    console.log('Searching for:', searchQuery);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#2C3E50] text-white shadow-md">
      {/* Main Header */}
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <Crystal size={24} className="mr-2" />
            <h1 className="text-2xl font-bold">YourMineral</h1>
          </Link>

          {/* Search Bar - Hidden on mobile */}
          <div className="hidden md:block flex-grow mx-6">
            <form onSubmit={handleSearch} className="flex w-full max-w-3xl mx-auto">
              <input
                type="text"
                placeholder="Search minerals, gems, and precious stones..."
                className="w-full px-4 py-2 text-black rounded-l-md focus:outline-none"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                type="submit"
                className="bg-[#E67E22] px-4 py-2 rounded-r-md hover:bg-[#D35400] transition duration-200"
              >
                <Search size={20} />
              </button>
            </form>
          </div>

          {/* Right Navigation */}
          <div className="flex items-center space-x-4">
            <Link to="/account" className="hover:text-gray-200 transition duration-200">
              <div className="flex flex-col items-center">
                <User size={20} />
                <span className="text-xs hidden sm:block">Account</span>
              </div>
            </Link>
            <Link to="/cart" className="hover:text-gray-200 transition duration-200 relative">
              <div className="flex flex-col items-center">
                <ShoppingCart size={20} />
                <span className="text-xs hidden sm:block">Cart</span>
              </div>
              {cart.totalItems > 0 && (
                <div className="absolute -top-2 -right-2 bg-[#E67E22] text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cart.totalItems}
                </div>
              )}
            </Link>
            <button 
              className="md:hidden"
              onClick={toggleMobileMenu}
              aria-label="Toggle menu"
            >
              <Menu size={24} />
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="mt-3 md:hidden">
          <form onSubmit={handleSearch} className="flex w-full">
            <input
              type="text"
              placeholder="Search minerals..."
              className="w-full px-4 py-2 text-black rounded-l-md focus:outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-[#E67E22] px-4 py-2 rounded-r-md hover:bg-[#D35400] transition duration-200"
            >
              <Search size={20} />
            </button>
          </form>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <nav className="bg-[#34495E] md:hidden">
          <div className="container mx-auto px-4 py-2">
            <ul className="space-y-2">
              <li><Link to="/category/precious stones" className="block py-2 hover:text-[#E67E22]">Precious Stones</Link></li>
              <li><Link to="/category/crystals" className="block py-2 hover:text-[#E67E22]">Crystals</Link></li>
              <li><Link to="/category/precious metals" className="block py-2 hover:text-[#E67E22]">Precious Metals</Link></li>
              <li><Link to="/deals" className="block py-2 hover:text-[#E67E22]">Special Offers</Link></li>
            </ul>
          </div>
        </nav>
      )}

      {/* Desktop Categories Navigation */}
      <nav className="bg-[#34495E] hidden md:block">
        <div className="container mx-auto px-4">
          <ul className="flex space-x-6 py-2">
            <li><Link to="/category/precious stones" className="hover:text-[#E67E22] transition duration-200">Precious Stones</Link></li>
            <li><Link to="/category/crystals" className="hover:text-[#E67E22] transition duration-200">Crystals</Link></li>
            <li><Link to="/category/precious metals" className="hover:text-[#E67E22] transition duration-200">Precious Metals</Link></li>
            <li><Link to="/deals" className="hover:text-[#E67E22] transition duration-200">Special Offers</Link></li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;