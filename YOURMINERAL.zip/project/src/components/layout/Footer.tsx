import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0F3460] text-white mt-16">
      {/* Back to top button */}
      <div className="bg-[#0A2647] text-center py-3 cursor-pointer hover:bg-[#073677] transition duration-200">
        <button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="font-medium"
        >
          Back to top
        </button>
      </div>

      {/* Main footer content */}
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Get to Know Us */}
          <div>
            <h3 className="text-lg font-bold mb-4">Get to Know Us</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="hover:text-[#FF9F1C] transition duration-200">About ShopHub</Link></li>
              <li><Link to="/careers" className="hover:text-[#FF9F1C] transition duration-200">Careers</Link></li>
              <li><Link to="/press" className="hover:text-[#FF9F1C] transition duration-200">Press Releases</Link></li>
              <li><Link to="/sustainability" className="hover:text-[#FF9F1C] transition duration-200">Sustainability</Link></li>
            </ul>
          </div>

          {/* Make Money with Us */}
          <div>
            <h3 className="text-lg font-bold mb-4">Make Money with Us</h3>
            <ul className="space-y-2">
              <li><Link to="/sell" className="hover:text-[#FF9F1C] transition duration-200">Sell on ShopHub</Link></li>
              <li><Link to="/associates" className="hover:text-[#FF9F1C] transition duration-200">Become an Affiliate</Link></li>
              <li><Link to="/advertise" className="hover:text-[#FF9F1C] transition duration-200">Advertise Your Products</Link></li>
              <li><Link to="/vendor" className="hover:text-[#FF9F1C] transition duration-200">Become a Vendor</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-lg font-bold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link to="/help" className="hover:text-[#FF9F1C] transition duration-200">Help Center</Link></li>
              <li><Link to="/returns" className="hover:text-[#FF9F1C] transition duration-200">Returns & Replacements</Link></li>
              <li><Link to="/shipping" className="hover:text-[#FF9F1C] transition duration-200">Shipping Rates & Policies</Link></li>
              <li><Link to="/contact" className="hover:text-[#FF9F1C] transition duration-200">Contact Us</Link></li>
            </ul>
          </div>

          {/* Connect with Us */}
          <div>
            <h3 className="text-lg font-bold mb-4">Connect with Us</h3>
            <div className="flex space-x-4 mb-4">
              <a href="#" className="hover:text-[#FF9F1C] transition duration-200" aria-label="Facebook">
                <Facebook size={24} />
              </a>
              <a href="#" className="hover:text-[#FF9F1C] transition duration-200" aria-label="Twitter">
                <Twitter size={24} />
              </a>
              <a href="#" className="hover:text-[#FF9F1C] transition duration-200" aria-label="Instagram">
                <Instagram size={24} />
              </a>
              <a href="#" className="hover:text-[#FF9F1C] transition duration-200" aria-label="Youtube">
                <Youtube size={24} />
              </a>
            </div>
            <div className="mb-4">
              <form className="flex">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="px-4 py-2 rounded-l-md text-black w-full focus:outline-none"
                />
                <button
                  type="submit"
                  className="bg-[#FF9F1C] px-4 py-2 rounded-r-md hover:bg-[#F7B32B] transition duration-200 flex items-center"
                >
                  <Mail size={20} />
                </button>
              </form>
              <p className="text-sm mt-2">Subscribe to our newsletter for updates</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom footer */}
      <div className="bg-[#0A2647] py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm">
            <div className="mb-4 md:mb-0">
              <p>&copy; 2025 ShopHub. All rights reserved.</p>
            </div>
            <div className="flex space-x-4">
              <Link to="/privacy" className="hover:text-[#FF9F1C] transition duration-200">Privacy Policy</Link>
              <Link to="/terms" className="hover:text-[#FF9F1C] transition duration-200">Terms of Service</Link>
              <Link to="/cookies" className="hover:text-[#FF9F1C] transition duration-200">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;