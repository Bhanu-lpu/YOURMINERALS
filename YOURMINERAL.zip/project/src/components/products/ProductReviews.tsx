import React from 'react';
import { Star, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Product } from '../../types/Product';

interface ProductReviewsProps {
  product: Product;
}

// Mock review data
const mockReviews = [
  {
    id: 1,
    username: 'Jane D.',
    date: '2025-04-15',
    rating: 5,
    title: 'Excellent product, highly recommended!',
    comment: 'This exceeded my expectations. The quality is outstanding and it arrived earlier than expected. Will definitely purchase again!',
    helpfulCount: 24,
    unhelpfulCount: 2,
    verified: true,
  },
  {
    id: 2,
    username: 'Michael S.',
    date: '2025-04-10',
    rating: 4,
    title: 'Good value for money',
    comment: 'Overall very satisfied with this purchase. The product is well-made and functions as described. Took a star off because the packaging could have been better.',
    helpfulCount: 15,
    unhelpfulCount: 1,
    verified: true,
  },
  {
    id: 3,
    username: 'Robert J.',
    date: '2025-04-02',
    rating: 3,
    title: 'Decent but has some issues',
    comment: 'The product itself is okay but there were a few minor issues. Customer service was helpful in resolving my concerns though.',
    helpfulCount: 8,
    unhelpfulCount: 3,
    verified: true,
  }
];

const ProductReviews: React.FC<ProductReviewsProps> = ({ product }) => {
  // Get the rating distribution
  const ratingCounts = [0, 0, 0, 0, 0];
  mockReviews.forEach(review => {
    if (review.rating >= 1 && review.rating <= 5) {
      ratingCounts[review.rating - 1]++;
    }
  });
  
  // Calculate total reviews
  const totalReviews = mockReviews.length;
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        {/* Overall Rating */}
        <div className="col-span-1">
          <div className="text-center">
            <div className="text-5xl font-bold mb-2">{product.rating.rate}</div>
            <div className="flex justify-center text-yellow-500 mb-2">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={20}
                  fill={i < Math.floor(product.rating.rate) ? 'currentColor' : 'none'}
                  className={i < Math.floor(product.rating.rate) ? 'text-yellow-500' : 'text-gray-300'}
                />
              ))}
            </div>
            <p className="text-gray-600">{product.rating.count} global ratings</p>
          </div>
        </div>
        
        {/* Rating Distribution */}
        <div className="col-span-2">
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => (
              <div key={rating} className="flex items-center">
                <span className="text-sm w-12">{rating} star</span>
                <div className="flex-grow mx-2 bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-yellow-500 h-3 rounded-full" 
                    style={{ width: `${totalReviews ? (ratingCounts[rating - 1] / totalReviews) * 100 : 0}%` }}
                  ></div>
                </div>
                <span className="text-sm text-gray-600 w-12">{Math.round(totalReviews ? (ratingCounts[rating - 1] / totalReviews) * 100 : 0)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Review List */}
      <div className="space-y-6">
        {mockReviews.map((review) => (
          <div key={review.id} className="border-b border-gray-200 pb-6">
            <div className="flex items-start">
              <div className="bg-gray-100 rounded-full w-10 h-10 flex items-center justify-center font-bold text-[#0F3460]">
                {review.username.charAt(0)}
              </div>
              <div className="ml-4">
                <p className="font-medium">{review.username}</p>
                {review.verified && (
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">Verified Purchase</span>
                )}
              </div>
            </div>
            
            <div className="mt-3">
              <div className="flex items-center mb-2">
                <div className="flex text-yellow-500 mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      fill={i < review.rating ? 'currentColor' : 'none'}
                      className={i < review.rating ? 'text-yellow-500' : 'text-gray-300'}
                    />
                  ))}
                </div>
                <h3 className="font-bold">{review.title}</h3>
              </div>
              
              <p className="text-sm text-gray-600 mb-1">
                Reviewed on {new Date(review.date).toLocaleDateString()}
              </p>
              
              <p className="text-gray-700 mb-4">{review.comment}</p>
              
              <div className="flex items-center text-sm text-gray-600">
                <span className="mr-4">Was this review helpful?</span>
                <button className="flex items-center mr-3 hover:text-[#0F3460]">
                  <ThumbsUp size={16} className="mr-1" />
                  <span>{review.helpfulCount}</span>
                </button>
                <button className="flex items-center hover:text-[#0F3460]">
                  <ThumbsDown size={16} className="mr-1" />
                  <span>{review.unhelpfulCount}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Review Form Button */}
      <div className="mt-8 text-center">
        <button className="bg-[#0F3460] text-white px-6 py-2 rounded-md hover:bg-[#0A2647] transition duration-200">
          Write a Review
        </button>
      </div>
    </div>
  );
};

export default ProductReviews;