import React from 'react';
import { Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product } from '../../types/Product';
import { useCart } from '../../contexts/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  
  // Format the price with 2 decimal places
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(product.price);
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
      <Link to={`/product/${product.id}`} className="block">
        <div className="h-48 p-4 flex items-center justify-center bg-gray-100">
          <img 
            src={product.image} 
            alt={product.title}
            className="h-full object-contain"
            loading="lazy"
          />
        </div>
      </Link>
      
      <div className="p-4">
        <Link to={`/product/${product.id}`} className="block">
          <h2 className="text-lg font-medium mb-2 line-clamp-2 min-h-[3.5rem]">{product.title}</h2>
        </Link>
        
        <div className="flex items-center mb-2">
          <div className="flex items-center text-yellow-500 mr-2">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={16}
                fill={i < Math.floor(product.rating.rate) ? 'currentColor' : 'none'}
                className={i < Math.floor(product.rating.rate) ? 'text-yellow-500' : 'text-gray-300'}
              />
            ))}
          </div>
          <span className="text-sm text-gray-600">({product.rating.count})</span>
        </div>
        
        <div className="flex items-center justify-between mt-4">
          <span className="text-xl font-bold">{formattedPrice}</span>
          <button
            onClick={() => addToCart(product)}
            className="bg-[#0F3460] text-white px-3 py-1 rounded-md hover:bg-[#0A2647] transition duration-200"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;