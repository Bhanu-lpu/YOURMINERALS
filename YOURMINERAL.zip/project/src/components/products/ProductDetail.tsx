import React, { useState } from 'react';
import { Star, ShoppingCart, Heart, TruckIcon } from 'lucide-react';
import { Product } from '../../types/Product';
import { useCart } from '../../contexts/CartContext';
import ProductReviews from './ProductReviews';

interface ProductDetailProps {
  product: Product;
  relatedProducts: Product[];
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, relatedProducts }) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  
  const handleQuantityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setQuantity(parseInt(e.target.value));
  };
  
  const handleAddToCart = () => {
    // Add the product to cart multiple times based on quantity
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };
  
  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };
  
  // Format price
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(product.price);
  
  // Estimate delivery date (5 days from now)
  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 5);
  const formattedDeliveryDate = deliveryDate.toLocaleDateString('en-US', {
    weekday: 'long', 
    month: 'long', 
    day: 'numeric'
  });
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
          {/* Product Image */}
          <div className="flex justify-center items-center bg-gray-50 p-8 rounded-lg">
            <img 
              src={product.image} 
              alt={product.title} 
              className="max-h-[400px] object-contain"
            />
          </div>
          
          {/* Product Info */}
          <div>
            <h1 className="text-2xl font-bold mb-2">{product.title}</h1>
            <div className="flex items-center mb-4">
              <div className="flex text-yellow-500 mr-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={18}
                    fill={i < Math.floor(product.rating.rate) ? 'currentColor' : 'none'}
                    className={i < Math.floor(product.rating.rate) ? 'text-yellow-500' : 'text-gray-300'}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">{product.rating.rate} ({product.rating.count} reviews)</span>
            </div>
            
            <div className="border-t border-b border-gray-200 py-4 my-4">
              <div className="text-3xl font-bold mb-2">{formattedPrice}</div>
              <p className="text-sm text-gray-500">Category: {product.category}</p>
            </div>
            
            <div className="mb-6">
              <p className="text-gray-700 mb-4">{product.description}</p>
              
              <div className="flex items-center text-green-600 mb-4">
                <TruckIcon size={18} className="mr-2" />
                <span>FREE delivery by {formattedDeliveryDate}</span>
              </div>
            </div>
            
            <div className="flex items-center mb-6">
              <div className="mr-4">
                <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">
                  Quantity
                </label>
                <select
                  id="quantity"
                  value={quantity}
                  onChange={handleQuantityChange}
                  className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                >
                  {[...Array(10)].map((_, i) => (
                    <option key={i + 1} value={i + 1}>
                      {i + 1}
                    </option>
                  ))}
                </select>
              </div>
              
              <button
                onClick={toggleFavorite}
                className={`flex items-center px-4 py-2 rounded-md border ${
                  isFavorite 
                    ? 'border-red-500 text-red-500' 
                    : 'border-gray-300 text-gray-700 hover:border-gray-400'
                } transition duration-200`}
              >
                <Heart size={18} className="mr-1" fill={isFavorite ? 'currentColor' : 'none'} />
                <span>Wishlist</span>
              </button>
            </div>
            
            <button
              onClick={handleAddToCart}
              className="w-full bg-[#0F3460] text-white py-3 rounded-md font-medium hover:bg-[#0A2647] transition duration-300 flex items-center justify-center"
            >
              <ShoppingCart size={20} className="mr-2" />
              Add to Cart
            </button>
          </div>
        </div>
      </div>
      
      {/* Product Reviews */}
      <ProductReviews product={product} />
    </div>
  );
};

export default ProductDetail;