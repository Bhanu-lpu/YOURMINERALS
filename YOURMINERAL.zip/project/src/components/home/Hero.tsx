import React from 'react';
import { useNavigate } from 'react-router-dom';

const Hero: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="relative bg-gradient-to-r from-[#2C3E50] to-[#34495E] text-white">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="order-2 md:order-1">
            <h1 className="text-4xl lg:text-5xl font-bold mb-4">Discover Earth's Treasures</h1>
            <p className="text-xl lg:text-2xl mb-6">Premium minerals, crystals, and precious stones</p>
            <p className="mb-8 text-gray-200">Explore our curated collection of natural minerals, rare gemstones, and precious metals. Each piece is carefully selected and authenticated by our expert gemologists.</p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => navigate('/deals')}
                className="bg-[#E67E22] hover:bg-[#D35400] text-white px-8 py-3 rounded-md font-medium transition duration-300"
              >
                View Collection
              </button>
              <button 
                onClick={() => navigate('/category/precious stones')}
                className="bg-transparent border-2 border-white hover:bg-white hover:text-[#2C3E50] px-8 py-3 rounded-md font-medium transition duration-300"
              >
                Rare Finds
              </button>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <img 
              src="https://images.pexels.com/photos/5368824/pexels-photo-5368824.jpeg" 
              alt="Premium minerals collection"
              className="rounded-lg shadow-xl w-full h-auto" 
            />
          </div>
        </div>
      </div>

      {/* Categories Quick Access */}
      <div className="bg-white text-gray-800 py-8 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 text-center">
            <div 
              onClick={() => navigate('/category/precious stones')}
              className="bg-gray-100 rounded-lg p-6 cursor-pointer transition duration-300 hover:shadow-md hover:-translate-y-1"
            >
              <img 
                src="https://images.pexels.com/photos/68740/diamond-gem-cubic-zirconia-jewel-68740.jpeg" 
                alt="Precious Stones" 
                className="w-16 h-16 object-cover rounded-full mx-auto mb-4"
              />
              <h3 className="font-medium">Precious Stones</h3>
            </div>
            <div 
              onClick={() => navigate('/category/crystals')}
              className="bg-gray-100 rounded-lg p-6 cursor-pointer transition duration-300 hover:shadow-md hover:-translate-y-1"
            >
              <img 
                src="https://images.pexels.com/photos/5368822/pexels-photo-5368822.jpeg" 
                alt="Crystals" 
                className="w-16 h-16 object-cover rounded-full mx-auto mb-4"
              />
              <h3 className="font-medium">Crystals</h3>
            </div>
            <div 
              onClick={() => navigate('/category/precious metals')}
              className="bg-gray-100 rounded-lg p-6 cursor-pointer transition duration-300 hover:shadow-md hover:-translate-y-1"
            >
              <img 
                src="https://images.pexels.com/photos/4039947/pexels-photo-4039947.jpeg" 
                alt="Precious Metals" 
                className="w-16 h-16 object-cover rounded-full mx-auto mb-4"
              />
              <h3 className="font-medium">Precious Metals</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;