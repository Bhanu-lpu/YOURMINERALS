import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';

const CartSummary: React.FC = () => {
  const { cart } = useCart();
  const navigate = useNavigate();
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };
  
  const subtotal = cart.totalPrice;
  const shipping = subtotal > 50 ? 0 : 4.99;
  const tax = subtotal * 0.08; // Assuming 8% tax
  const total = subtotal + shipping + tax;
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold mb-4">Order Summary</h2>
      
      <div className="space-y-3 mb-6">
        <div className="flex justify-between">
          <span>Subtotal ({cart.totalItems} items)</span>
          <span>{formatCurrency(subtotal)}</span>
        </div>
        
        <div className="flex justify-between">
          <span>Shipping & Handling</span>
          <span>
            {shipping === 0 
              ? <span className="text-green-600">FREE</span> 
              : formatCurrency(shipping)
            }
          </span>
        </div>
        
        <div className="flex justify-between">
          <span>Estimated Tax</span>
          <span>{formatCurrency(tax)}</span>
        </div>
        
        <div className="border-t border-gray-200 pt-3 mt-3">
          <div className="flex justify-between font-bold text-lg">
            <span>Order Total</span>
            <span>{formatCurrency(total)}</span>
          </div>
        </div>
      </div>
      
      {cart.items.length > 0 && (
        <>
          <button 
            onClick={() => navigate('/checkout')}
            className="w-full bg-[#FF9F1C] text-white py-3 rounded-md font-medium hover:bg-[#F7B32B] transition duration-200 mb-2"
          >
            Proceed to Checkout
          </button>
          
          {subtotal < 50 && (
            <div className="mt-4 bg-blue-50 p-3 rounded-md">
              <p className="text-sm">
                Add <span className="font-bold">{formatCurrency(50 - subtotal)}</span> more to qualify for FREE shipping!
              </p>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{ width: `${Math.min(100, (subtotal / 50) * 100)}%` }}
                ></div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CartSummary;