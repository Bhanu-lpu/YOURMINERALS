import React from 'react';
import { Trash, Minus, Plus } from 'lucide-react';
import { CartItem as CartItemType } from '../../contexts/CartContext';
import { Link } from 'react-router-dom';

interface CartItemProps {
  item: CartItemType;
  updateQuantity: (id: number, quantity: number) => void;
  removeFromCart: (id: number) => void;
}

const CartItem: React.FC<CartItemProps> = ({ item, updateQuantity, removeFromCart }) => {
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(item.price);

  const formattedTotal = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(item.price * item.quantity);

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center py-4 border-b border-gray-200">
      {/* Product Image */}
      <div className="w-full sm:w-24 h-24 flex-shrink-0 mb-4 sm:mb-0">
        <Link to={`/product/${item.id}`}>
          <img 
            src={item.image} 
            alt={item.title} 
            className="w-24 h-24 object-contain"
          />
        </Link>
      </div>
      
      {/* Product Info */}
      <div className="flex-grow sm:ml-6">
        <Link to={`/product/${item.id}`} className="text-lg font-medium hover:text-[#0F3460] transition duration-200">
          {item.title}
        </Link>
        <p className="text-sm text-gray-500 mb-2">Category: {item.category}</p>
        <p className="text-gray-700">{formattedPrice} each</p>
      </div>
      
      {/* Quantity Controls */}
      <div className="flex items-center mt-4 sm:mt-0">
        <div className="flex items-center mr-6">
          <button 
            onClick={() => updateQuantity(item.id, item.quantity - 1)}
            disabled={item.quantity <= 1}
            className="flex items-center justify-center w-8 h-8 rounded-md border border-gray-300 text-gray-600 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Decrease quantity"
          >
            <Minus size={16} />
          </button>
          <span className="mx-3">{item.quantity}</span>
          <button 
            onClick={() => updateQuantity(item.id, item.quantity + 1)}
            className="flex items-center justify-center w-8 h-8 rounded-md border border-gray-300 text-gray-600 hover:bg-gray-100"
            aria-label="Increase quantity"
          >
            <Plus size={16} />
          </button>
        </div>
        
        {/* Item Total */}
        <div className="w-24 text-right font-bold">{formattedTotal}</div>
        
        {/* Remove Button */}
        <button 
          onClick={() => removeFromCart(item.id)}
          className="ml-4 text-red-500 hover:text-red-700 transition duration-200"
          aria-label="Remove item"
        >
          <Trash size={20} />
        </button>
      </div>
    </div>
  );
};

export default CartItem;