import { Product } from '../types/Product';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    title: "Natural Raw Diamond Crystal",
    price: 2499.95,
    description: "Authentic raw diamond crystal specimen, perfect for collectors and investors. This natural, uncut diamond showcases the mineral's pure crystalline structure.",
    category: "precious stones",
    image: "https://images.pexels.com/photos/68740/diamond-gem-cubic-zirconia-jewel-68740.jpeg",
    rating: {
      rate: 4.8,
      count: 45
    }
  },
  {
    id: 2,
    title: "Premium Amethyst Cluster",
    price: 299.99,
    description: "Beautiful deep purple amethyst cluster from Brazil, featuring stunning crystal formations and intense color. Perfect for display or metaphysical purposes.",
    category: "crystals",
    image: "https://images.pexels.com/photos/5368824/pexels-photo-5368824.jpeg",
    rating: {
      rate: 4.9,
      count: 128
    }
  },
  {
    id: 3,
    title: "Large Rose Quartz Specimen",
    price: 159.99,
    description: "High-quality rose quartz specimen with excellent clarity and beautiful pink hue. Known for its healing properties and aesthetic appeal.",
    category: "crystals",
    image: "https://images.pexels.com/photos/6994272/pexels-photo-6994272.jpeg",
    rating: {
      rate: 4.7,
      count: 89
    }
  },
  {
    id: 4,
    title: "Raw Gold Nugget",
    price: 3499.99,
    description: "Authentic natural gold nugget from Alaska, perfect for collectors or investors. High purity with beautiful natural formation.",
    category: "precious metals",
    image: "https://images.pexels.com/photos/4039947/pexels-photo-4039947.jpeg",
    rating: {
      rate: 4.9,
      count: 32
    }
  },
  {
    id: 5,
    title: "Premium Emerald Crystal",
    price: 1895.00,
    description: "Natural emerald crystal specimen from Colombia, displaying excellent color and crystal structure. A must-have for serious collectors.",
    category: "precious stones",
    image: "https://images.pexels.com/photos/4040586/pexels-photo-4040586.jpeg",
    rating: {
      rate: 4.6,
      count: 67
    }
  },
  {
    id: 6,
    title: "Large Selenite Tower",
    price: 89.99,
    description: "Premium quality selenite tower, hand-carved and polished to perfection. Known for its cleansing and purifying properties.",
    category: "crystals",
    image: "https://images.pexels.com/photos/6994267/pexels-photo-6994267.jpeg",
    rating: {
      rate: 4.3,
      count: 156
    }
  },
  {
    id: 7,
    title: "Raw Silver Specimen",
    price: 449.99,
    description: "Natural silver specimen showing beautiful dendritic growth patterns. Perfect for collectors interested in precious metals in their natural form.",
    category: "precious metals",
    image: "https://images.pexels.com/photos/4040588/pexels-photo-4040588.jpeg",
    rating: {
      rate: 4.5,
      count: 78
    }
  },
  {
    id: 8,
    title: "Black Tourmaline Crystal",
    price: 129.99,
    description: "Large black tourmaline crystal with excellent termination. Known for its protective properties and striking appearance.",
    category: "crystals",
    image: "https://images.pexels.com/photos/5368822/pexels-photo-5368822.jpeg",
    rating: {
      rate: 4.4,
      count: 112
    }
  },
  {
    id: 9,
    title: "Premium Sapphire Crystal",
    price: 1299.99,
    description: "Natural blue sapphire crystal specimen from Sri Lanka. Beautiful color and crystal structure make this a collector's dream.",
    category: "precious stones",
    image: "https://images.pexels.com/photos/4040587/pexels-photo-4040587.jpeg",
    rating: {
      rate: 4.8,
      count: 54
    }
  },
  {
    id: 10,
    title: "Large Citrine Cluster",
    price: 259.99,
    description: "Natural citrine cluster with beautiful golden color. Features multiple crystal points and excellent clarity.",
    category: "crystals",
    image: "https://images.pexels.com/photos/5368826/pexels-photo-5368826.jpeg",
    rating: {
      rate: 4.6,
      count: 98
    }
  },
  {
    id: 11,
    title: "Platinum Nugget",
    price: 4999.99,
    description: "Rare natural platinum nugget, perfect for collectors and investors. High purity with unique natural formation.",
    category: "precious metals",
    image: "https://images.pexels.com/photos/4039948/pexels-photo-4039948.jpeg",
    rating: {
      rate: 4.9,
      count: 23
    }
  },
  {
    id: 12,
    title: "Large Labradorite Specimen",
    price: 199.99,
    description: "Premium labradorite specimen with exceptional flash and iridescence. Polished face shows stunning blue and green flashes.",
    category: "crystals",
    image: "https://images.pexels.com/photos/5368827/pexels-photo-5368827.jpeg",
    rating: {
      rate: 4.7,
      count: 145
    }
  },
  {
    id: 13,
    title: "Ruby Crystal Specimen",
    price: 1699.99,
    description: "Natural ruby crystal in matrix from Myanmar. Deep red color and excellent crystal formation make this a spectacular specimen.",
    category: "precious stones",
    image: "https://images.pexels.com/photos/4040585/pexels-photo-4040585.jpeg",
    rating: {
      rate: 4.8,
      count: 42
    }
  },
  {
    id: 14,
    title: "Clear Quartz Point",
    price: 79.99,
    description: "Large clear quartz crystal point with excellent clarity and termination. Perfect for meditation and energy work.",
    category: "crystals",
    image: "https://images.pexels.com/photos/5368825/pexels-photo-5368825.jpeg",
    rating: {
      rate: 4.5,
      count: 167
    }
  },
  {
    id: 15,
    title: "Rhodochrosite Specimen",
    price: 349.99,
    description: "Beautiful rhodochrosite specimen from Argentina featuring stunning pink banding and crystal formation.",
    category: "crystals",
    image: "https://images.pexels.com/photos/5368823/pexels-photo-5368823.jpeg",
    rating: {
      rate: 4.6,
      count: 88
    }
  }
];

// Filter products by category
export const getProductsByCategory = (category: string): Product[] => {
  return PRODUCTS.filter(product => product.category === category);
};

// Get a specific product by ID
export const getProductById = (id: number): Product | undefined => {
  return PRODUCTS.find(product => product.id === id);
};

// Get related products (products in the same category, excluding the current product)
export const getRelatedProducts = (productId: number, limit: number = 4): Product[] => {
  const product = getProductById(productId);
  if (!product) return [];
  
  return PRODUCTS
    .filter(p => p.category === product.category && p.id !== productId)
    .slice(0, limit);
};

// Get featured products (highest rated products)
export const getFeaturedProducts = (limit: number = 8): Product[] => {
  return [...PRODUCTS]
    .sort((a, b) => b.rating.rate - a.rating.rate)
    .slice(0, limit);
};

// Get trending products (most reviewed products)
export const getTrendingProducts = (limit: number = 4): Product[] => {
  return [...PRODUCTS]
    .sort((a, b) => b.rating.count - a.rating.count)
    .slice(0, limit);
};

// Get new arrivals (newest products, using ID as a proxy for newness)
export const getNewArrivals = (limit: number = 4): Product[] => {
  return [...PRODUCTS]
    .sort((a, b) => b.id - a.id)
    .slice(0, limit);
};

// Search products
export const searchProducts = (query: string): Product[] => {
  const lowercaseQuery = query.toLowerCase();
  return PRODUCTS.filter(product => 
    product.title.toLowerCase().includes(lowercaseQuery) || 
    product.description.toLowerCase().includes(lowercaseQuery) ||
    product.category.toLowerCase().includes(lowercaseQuery)
  );
};