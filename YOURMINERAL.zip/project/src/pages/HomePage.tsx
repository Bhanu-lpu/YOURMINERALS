import React from 'react';
import Hero from '../components/home/Hero';
import ProductGrid from '../components/products/ProductGrid';
import { getFeaturedProducts, getNewArrivals, getTrendingProducts } from '../data/products';

const HomePage: React.FC = () => {
  const featuredProducts = getFeaturedProducts(8);
  const newArrivals = getNewArrivals(4);
  const trendingProducts = getTrendingProducts(4);

  return (
    <div>
      <Hero />
      
      <div className="container mx-auto px-4 py-12">
        {/* Featured Products */}
        <ProductGrid products={featuredProducts} title="Featured Products" />
        
        {/* New Arrivals and Trending Products */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <div>
            <h2 className="text-2xl font-bold mb-6">New Arrivals</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {newArrivals.map((product) => (
                  <div key={product.id} className="flex space-x-4">
                    <img 
                      src={product.image} 
                      alt={product.title} 
                      className="w-20 h-20 object-contain" 
                    />
                    <div>
                      <h3 className="font-medium text-gray-800 line-clamp-2">{product.title}</h3>
                      <p className="text-[#0F3460] font-bold mt-1">
                        ${product.price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-2xl font-bold mb-6">Trending Now</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {trendingProducts.map((product) => (
                  <div key={product.id} className="flex space-x-4">
                    <img 
                      src={product.image} 
                      alt={product.title} 
                      className="w-20 h-20 object-contain" 
                    />
                    <div>
                      <h3 className="font-medium text-gray-800 line-clamp-2">{product.title}</h3>
                      <p className="text-[#0F3460] font-bold mt-1">
                        ${product.price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Special Offers Banner */}
        <div className="bg-gradient-to-r from-[#16213E] to-[#0F3460] text-white rounded-lg shadow-xl mb-16 overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 items-center">
            <div className="p-8 md:p-12">
              <h2 className="text-3xl font-bold mb-4">Special Offer</h2>
              <p className="text-lg mb-6">Get up to 40% off on selected electronics this week!</p>
              <button className="bg-[#FF9F1C] hover:bg-[#F7B32B] text-white px-6 py-3 rounded-md font-medium transition duration-300">
                Shop Now
              </button>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.pexels.com/photos/1787236/pexels-photo-1787236.jpeg" 
                alt="Special offer electronics" 
                className="w-full h-full object-cover object-center"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;