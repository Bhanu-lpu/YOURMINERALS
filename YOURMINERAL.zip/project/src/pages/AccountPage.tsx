import React, { useState } from 'react';
import { Package, User, Heart, Clock, CreditCard, Settings, UserPlus, LogIn } from 'lucide-react';

const AccountPage: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState('orders');
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showLogin, setShowLogin] = useState(true);

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginForm(prev => ({ ...prev, [name]: value }));
  };

  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRegisterForm(prev => ({ ...prev, [name]: value }));
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate successful login
    setIsLoggedIn(true);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate successful registration and login
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  // Mock order data
  const mockOrders = [
    {
      id: 'ORD-12345',
      date: '2025-04-15',
      total: 127.95,
      status: 'Delivered',
      items: [
        { id: 1, name: 'Fjallraven Backpack', price: 109.95, quantity: 1 },
        { id: 2, name: 'Mens Casual T-Shirt', price: 18.00, quantity: 1 }
      ]
    },
    {
      id: 'ORD-12346',
      date: '2025-04-10',
      total: 55.99,
      status: 'Shipped',
      items: [
        { id: 3, name: 'Mens Cotton Jacket', price: 55.99, quantity: 1 }
      ]
    }
  ];

  // Mock wishlist data
  const mockWishlist = [
    { id: 5, name: 'John Hardy Women\'s Bracelet', price: 695.00, image: 'https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg' },
    { id: 13, name: 'Acer SB220Q Monitor', price: 599.00, image: 'https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg' },
    { id: 14, name: 'Samsung Gaming Monitor', price: 999.99, image: 'https://fakestoreapi.com/img/81Zt42ioCgL._AC_SX679_.jpg' }
  ];

  if (!isLoggedIn) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
          <div className="flex border-b">
            <button
              className={`w-1/2 py-4 font-medium ${showLogin ? 'bg-[#0F3460] text-white' : 'text-gray-700'}`}
              onClick={() => setShowLogin(true)}
            >
              <LogIn size={18} className="inline mr-2" />
              Login
            </button>
            <button
              className={`w-1/2 py-4 font-medium ${!showLogin ? 'bg-[#0F3460] text-white' : 'text-gray-700'}`}
              onClick={() => setShowLogin(false)}
            >
              <UserPlus size={18} className="inline mr-2" />
              Register
            </button>
          </div>
          
          <div className="p-6">
            {showLogin ? (
              <form onSubmit={handleLogin}>
                <h2 className="text-2xl font-bold mb-6">Sign In</h2>
                
                <div className="mb-4">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={loginForm.email}
                    onChange={handleLoginChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                    required
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={loginForm.password}
                    onChange={handleLoginChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                    required
                  />
                  <p className="text-sm text-right mt-1">
                    <a href="#" className="text-[#0F3460] hover:underline">Forgot password?</a>
                  </p>
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-[#0F3460] text-white py-2 rounded-md font-medium hover:bg-[#0A2647] transition duration-300"
                >
                  Sign In
                </button>
              </form>
            ) : (
              <form onSubmit={handleRegister}>
                <h2 className="text-2xl font-bold mb-6">Create Account</h2>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      name="firstName"
                      value={registerForm.firstName}
                      onChange={handleRegisterChange}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      name="lastName"
                      value={registerForm.lastName}
                      onChange={handleRegisterChange}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                      required
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="registerEmail" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="registerEmail"
                    name="email"
                    value={registerForm.email}
                    onChange={handleRegisterChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                    required
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="registerPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    id="registerPassword"
                    name="password"
                    value={registerForm.password}
                    onChange={handleRegisterChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                    required
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    value={registerForm.confirmPassword}
                    onChange={handleRegisterChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                    required
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-[#0F3460] text-white py-2 rounded-md font-medium hover:bg-[#0A2647] transition duration-300"
                >
                  Create Account
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-white rounded-lg shadow-md p-4 h-fit">
          <div className="flex items-center space-x-4 mb-6 pb-6 border-b border-gray-200">
            <div className="bg-[#0F3460] text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl">
              J
            </div>
            <div>
              <p className="font-medium">John Doe</p>
              <p className="text-sm text-gray-600">john.doe@example.com</p>
            </div>
          </div>
          
          <nav>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                    activeTab === 'orders' ? 'bg-[#0F3460] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <Package size={18} />
                  <span>My Orders</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                    activeTab === 'profile' ? 'bg-[#0F3460] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <User size={18} />
                  <span>Profile</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('wishlist')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                    activeTab === 'wishlist' ? 'bg-[#0F3460] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <Heart size={18} />
                  <span>Wishlist</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('history')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                    activeTab === 'history' ? 'bg-[#0F3460] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <Clock size={18} />
                  <span>Browsing History</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('payment')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                    activeTab === 'payment' ? 'bg-[#0F3460] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <CreditCard size={18} />
                  <span>Payment Methods</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                    activeTab === 'settings' ? 'bg-[#0F3460] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <Settings size={18} />
                  <span>Account Settings</span>
                </button>
              </li>
            </ul>
          </nav>
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <button
              onClick={handleLogout}
              className="w-full bg-gray-100 text-gray-800 px-3 py-2 rounded-md hover:bg-gray-200 transition duration-200"
            >
              Sign Out
            </button>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="flex-grow">
          {activeTab === 'orders' && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold">My Orders</h2>
              </div>
              
              {mockOrders.length === 0 ? (
                <div className="p-6 text-center">
                  <p className="text-gray-600 mb-4">You haven't placed any orders yet.</p>
                  <a href="/products" className="text-[#0F3460] font-medium hover:underline">
                    Start Shopping
                  </a>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {mockOrders.map((order) => (
                    <div key={order.id} className="p-6">
                      <div className="flex flex-wrap justify-between items-start mb-4">
                        <div>
                          <h3 className="font-medium">Order #{order.id}</h3>
                          <p className="text-sm text-gray-600">
                            Placed on {new Date(order.date).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">${order.total.toFixed(2)}</p>
                          <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                            order.status === 'Delivered' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-3 mb-4">
                        {order.items.map((item) => (
                          <div key={item.id} className="flex justify-between">
                            <div>
                              <p>{item.name}</p>
                              <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                            </div>
                            <p>${item.price.toFixed(2)}</p>
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex justify-between mt-4">
                        <button className="text-[#0F3460] hover:underline">View Order Details</button>
                        <button className="bg-[#0F3460] text-white px-4 py-1 rounded-md hover:bg-[#0A2647] transition duration-200">
                          Buy Again
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'wishlist' && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold">My Wishlist</h2>
              </div>
              
              {mockWishlist.length === 0 ? (
                <div className="p-6 text-center">
                  <p className="text-gray-600 mb-4">Your wishlist is empty.</p>
                  <a href="/products" className="text-[#0F3460] font-medium hover:underline">
                    Explore Products
                  </a>
                </div>
              ) : (
                <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {mockWishlist.map((item) => (
                    <div key={item.id} className="border border-gray-200 rounded-md overflow-hidden">
                      <div className="h-40 p-4 flex items-center justify-center bg-gray-50">
                        <img src={item.image} alt={item.name} className="h-full object-contain" />
                      </div>
                      <div className="p-4">
                        <h3 className="font-medium line-clamp-2">{item.name}</h3>
                        <p className="text-[#0F3460] font-bold my-2">${item.price.toFixed(2)}</p>
                        <div className="flex justify-between mt-4">
                          <button className="text-gray-600 hover:text-red-500">
                            <Heart size={18} fill="currentColor" />
                          </button>
                          <button className="bg-[#0F3460] text-white px-3 py-1 rounded-md hover:bg-[#0A2647] transition duration-200">
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'profile' && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold">My Profile</h2>
              </div>
              <div className="p-6">
                <form>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        value="John"
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        value="Doe"
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value="john.doe@example.com"
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        value="(555) 123-4567"
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F3460]"
                      />
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Default Address</h3>
                    <div className="border border-gray-200 rounded-md p-4">
                      <p>John Doe</p>
                      <p>123 Main Street</p>
                      <p>Apt 4B</p>
                      <p>New York, NY 10001</p>
                      <p>United States</p>
                      <div className="mt-3 flex space-x-4">
                        <button type="button" className="text-[#0F3460] hover:underline">Edit</button>
                        <button type="button" className="text-[#0F3460] hover:underline">Add New Address</button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="bg-[#0F3460] text-white px-6 py-2 rounded-md hover:bg-[#0A2647] transition duration-200"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
          
          {(activeTab === 'history' || activeTab === 'payment' || activeTab === 'settings') && (
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold">
                  {activeTab === 'history' && 'Browsing History'}
                  {activeTab === 'payment' && 'Payment Methods'}
                  {activeTab === 'settings' && 'Account Settings'}
                </h2>
              </div>
              <div className="p-6 text-center">
                <p className="text-gray-600 mb-4">
                  This feature is coming soon!
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccountPage;