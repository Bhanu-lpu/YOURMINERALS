import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import CartItem from '../components/cart/CartItem';
import CartSummary from '../components/cart/CartSummary';
import { ShoppingBag } from 'lucide-react';

const CartPage: React.FC = () => {
  const { cart, updateQuantity, removeFromCart } = useCart();

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Shopping Cart</h1>
      
      {cart.items.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="flex justify-center mb-4">
            <ShoppingBag size={64} className="text-gray-400" />
          </div>
          <h2 className="text-xl font-medium mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-6">Looks like you haven't added anything to your cart yet.</p>
          <Link 
            to="/products"
            className="bg-[#0F3460] text-white px-6 py-2 rounded-md hover:bg-[#0A2647] transition duration-200"
          >
            Start Shopping
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items List */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-4 pb-4 border-b border-gray-200">
                <h2 className="text-xl font-medium">
                  {cart.totalItems} {cart.totalItems === 1 ? 'Item' : 'Items'}
                </h2>
              </div>
              
              <div className="space-y-1">
                {cart.items.map((item) => (
                  <CartItem 
                    key={item.id}
                    item={item}
                    updateQuantity={updateQuantity}
                    removeFromCart={removeFromCart}
                  />
                ))}
              </div>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <CartSummary />
            
            <div className="mt-6 bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-bold mb-4">Customer Service</h2>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start">
                  <div className="text-[#0F3460] font-bold mr-2">•</div>
                  <p>Free shipping on orders over $50</p>
                </li>
                <li className="flex items-start">
                  <div className="text-[#0F3460] font-bold mr-2">•</div>
                  <p>30-day return policy</p>
                </li>
                <li className="flex items-start">
                  <div className="text-[#0F3460] font-bold mr-2">•</div>
                  <p>Secure payments</p>
                </li>
                <li className="flex items-start">
                  <div className="text-[#0F3460] font-bold mr-2">•</div>
                  <p>24/7 customer support</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;