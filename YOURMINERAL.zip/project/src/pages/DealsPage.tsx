import React from 'react';
import { PRODUCTS } from '../data/products';
import ProductGrid from '../components/products/ProductGrid';
import { Product } from '../types/Product';
import { Clock } from 'lucide-react';

const DealsPage: React.FC = () => {
  // Simulate "deals" by adding a discount to certain products
  const applyDiscount = (product: Product, discountPercent: number): Product => {
    const discountedPrice = product.price * (1 - discountPercent / 100);
    return {
      ...product,
      originalPrice: product.price,
      price: Number(discountedPrice.toFixed(2)),
      discountPercent,
    };
  };

  // Apply discounts to different product sets
  const featuredDeals = PRODUCTS.slice(0, 4).map(product => 
    applyDiscount(product, Math.floor(Math.random() * 20) + 30)
  );
  
  const dailyDeals = PRODUCTS.slice(4, 8).map(product => 
    applyDiscount(product, Math.floor(Math.random() * 15) + 20)
  );
  
  const weeklyDeals = PRODUCTS.slice(8, 16).map(product => 
    applyDiscount(product, Math.floor(Math.random() * 10) + 10)
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Today's Deals</h1>
      
      {/* Deal of the Day */}
      <div className="bg-gradient-to-r from-[#16213E] to-[#0F3460] text-white rounded-lg shadow-xl mb-10 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 items-center">
          <div className="p-8 md:p-12">
            <h2 className="text-3xl font-bold mb-2">Deal of the Day</h2>
            <div className="flex items-center space-x-2 mb-4">
              <Clock size={20} />
              <p>Ends in: 11h 32m 14s</p>
            </div>
            <h3 className="text-xl font-semibold mb-2">Samsung 49-Inch Curved Gaming Monitor</h3>
            <div className="mb-4">
              <span className="text-3xl font-bold">${featuredDeals[3].price}</span>
              <span className="ml-2 text-lg line-through opacity-70">${featuredDeals[3].originalPrice}</span>
              <span className="ml-2 bg-red-500 text-white px-2 py-1 rounded-md text-sm font-bold">
                {featuredDeals[3].discountPercent}% OFF
              </span>
            </div>
            <p className="mb-6">Experience immersive gaming with this ultra-wide curved monitor featuring QLED technology and 144Hz refresh rate.</p>
            <button className="bg-[#FF9F1C] hover:bg-[#F7B32B] text-white px-6 py-3 rounded-md font-medium transition duration-300">
              Shop Now
            </button>
          </div>
          <div className="hidden md:block">
            <img 
              src="https://fakestoreapi.com/img/81Zt42ioCgL._AC_SX679_.jpg" 
              alt="Samsung Monitor" 
              className="w-full h-64 object-contain bg-white p-4"
            />
          </div>
        </div>
      </div>
      
      {/* Featured Deals */}
      <div className="mb-10">
        <h2 className="text-xl font-bold mb-6">Featured Deals</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredDeals.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="relative">
                <div className="h-48 p-4 flex items-center justify-center bg-gray-50">
                  <img 
                    src={product.image} 
                    alt={product.title}
                    className="h-full object-contain"
                  />
                </div>
                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-md text-sm font-bold">
                  {product.discountPercent}% OFF
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="text-lg font-medium mb-2 line-clamp-1">{product.title}</h3>
                <div className="flex items-center mb-2">
                  <span className="text-xl font-bold text-[#0F3460]">${product.price}</span>
                  <span className="ml-2 text-sm text-gray-500 line-through">${product.originalPrice}</span>
                </div>
                <button className="w-full bg-[#0F3460] text-white py-2 rounded-md font-medium hover:bg-[#0A2647] transition duration-200">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Daily Deals */}
      <div className="mb-10">
        <h2 className="text-xl font-bold mb-6">Daily Deals</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {dailyDeals.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="relative">
                <div className="h-48 p-4 flex items-center justify-center bg-gray-50">
                  <img 
                    src={product.image} 
                    alt={product.title}
                    className="h-full object-contain"
                  />
                </div>
                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-md text-sm font-bold">
                  {product.discountPercent}% OFF
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="text-lg font-medium mb-2 line-clamp-1">{product.title}</h3>
                <div className="flex items-center mb-2">
                  <span className="text-xl font-bold text-[#0F3460]">${product.price}</span>
                  <span className="ml-2 text-sm text-gray-500 line-through">${product.originalPrice}</span>
                </div>
                <button className="w-full bg-[#0F3460] text-white py-2 rounded-md font-medium hover:bg-[#0A2647] transition duration-200">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Weekly Deals */}
      <div>
        <h2 className="text-xl font-bold mb-6">Weekly Deals</h2>
        <ProductGrid products={weeklyDeals} />
      </div>
    </div>
  );
};

export default DealsPage;