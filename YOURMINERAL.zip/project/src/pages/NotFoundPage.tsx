import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingBag } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <ShoppingBag size={80} className="mx-auto mb-6 text-[#0F3460]" />
      <h1 className="text-4xl font-bold mb-4">Page Not Found</h1>
      <p className="text-lg text-gray-600 mb-8 max-w-lg mx-auto">
        We're sorry, the page you're looking for doesn't exist or has been moved.
      </p>
      <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
        <button
          onClick={() => navigate('/')}
          className="bg-[#0F3460] text-white px-6 py-3 rounded-md font-medium hover:bg-[#0A2647] transition duration-300"
        >
          Go Home
        </button>
        <button
          onClick={() => navigate('/products')}
          className="bg-transparent border-2 border-[#0F3460] text-[#0F3460] px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition duration-300"
        >
          Browse Products
        </button>
      </div>
    </div>
  );
};

export default NotFoundPage;